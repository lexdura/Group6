/**
 * 
 */
/**
 * @author Justin
 *
 */
module Blackjack {
	requires java.desktop;
}